# eslint-ts-dotenv-setup

# eslint-ts-setup + dotenv confugured

Application has 1 file src/app.ts.

Typscript is set up and outdir is the dist folder.

EsLint setup included.

Nodemon setup included.

Development Mode Script:
npm run start
Production Mode Script:
npm run build
