const requestAllFromDB = async () => {
  const data = [{
      title: "Item 1",
  }];

  return data;
};

export { requestAllFromDB };
