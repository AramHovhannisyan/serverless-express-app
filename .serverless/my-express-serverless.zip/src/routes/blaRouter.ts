import express from 'express';
import { getBla } from '../controllers/blaController';

const blaRouter = express.Router();
blaRouter.route('/').get(getBla);

export { blaRouter };